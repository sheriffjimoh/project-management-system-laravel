
		<!-- ============================================ -->
    <script src="{{ asset('app-assets/js/vendor/jquery-1.12.4.min.js')}}"></script>
    <!-- bootstrap JS
		============================================ -->
    <script src="{{ asset('app-assets/js/bootstrap.min.js')}}"></script>
    <!-- wow JS
		============================================ -->
    <script src="{{ asset('app-assets/js/wow.min.js')}}"></script>
    <!-- price-slider JS
		============================================ -->
    <script src="{{ asset('app-assets/js/jquery-price-slider.js')}}"></script>
    <!-- meanmenu JS
		============================================ -->
    <script src="{{ asset('app-assets/js/jquery.meanmenu.js')}}"></script>
    <!-- owl.carousel JS
		============================================ -->
    <script src="{{ asset('app-assets/js/owl.carousel.min.js')}}"></script>
    <!-- sticky JS
		============================================ -->
    <script src="{{ asset('app-assets/js/jquery.sticky.js')}}"></script>
    <!-- scrollUp JS
		============================================ -->
    <script src="{{ asset('app-assets/js/jquery.scrollUp.min.js')}}"></script>
    <!-- counterup JS
		============================================ -->
    <script src="{{ asset('app-assets/js/counterup/jquery.counterup.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/counterup/waypoints.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/counterup/counterup-active.js')}}"></script>
    <!-- mCustomScrollbar JS
		============================================ -->
    <script src="{{ asset('app-assets/js/scrollbar/jquery.mCustomScrollbar.concat.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/scrollbar/mCustomScrollbar-active.js')}}"></script>
    <!-- metisMenu JS
		============================================ -->
    <script src="{{ asset('app-assets/js/metisMenu/metisMenu.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/metisMenu/metisMenu-active.js')}}"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="{{ asset('app-assets/js/morrisjs/raphael-min.js')}}"></script>
    <script src="{{ asset('app-assets/js/morrisjs/morris.js')}}"></script>
    <script src="{{ asset('app-assets/js/morrisjs/morris-active.js')}}"></script>
    <!-- morrisjs JS
		============================================ -->
    <script src="{{ asset('app-assets/js/sparkline/jquery.sparkline.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/sparkline/jquery.charts-sparkline.js')}}"></script>
    <script src="{{ asset('app-assets/js/sparkline/sparkline-active.js')}}"></script>
    <!-- calendar JS
		============================================ -->
    <script src="{{ asset('app-assets/js/calendar/moment.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/calendar/fullcalendar.min.js')}}"></script>
    <script src="{{ asset('app-assets/js/calendar/fullcalendar-active.js')}}"></script>
    <!-- plugins JS
		============================================ -->
    <script src="{{ asset('app-assets/js/plugins.js')}}"></script>
    <!-- main JS
		============================================ -->
    <script src="{{ asset('app-assets/js/main.js')}}"></script>
    <!-- tawk chat JS


		============================================ -->

        <script src="https://code.jquery.com/jquery-3.5.1.js" integrity="sha256-QWo7LDvxbWT2tbbQ97B53yJnYU3WhH/C8ycbRAkjPDc=" crossorigin="anonymous"></script>

        
<!-- Latest compiled and minified JavaScript -->
<!-- <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script> -->