



 
      <?php $__env->startSection('content'); ?>
       <?php echo $__env->make('includes.addcompany', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
       <br><br>

        <!-- Mobile Menu end -->
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                         <?php echo e(Auth::user()->firstname.' '.Auth::user()->lastname); ?>

                                        </div>
                                    </div>
                                   
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="/home">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">myprofile</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
            <?php if($errors->any()): ?>
                <div class='alert alert-danger alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-warning'></i> Error!</h4>
                    <ul>
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
            <?php endif; ?>

             <?php if(session('status')): ?>
             <div class='alert alert-success alert-dismissible'>
              <button type='button' class='close' data-dismiss='alert' aria-hidden='true'>&times;</button>
              <h4><i class='icon fa fa-check'></i> Success!</h4>
                  <?php echo e(session('status')); ?>

              </div>
          <?php endif; ?>

   <main role="main" class="container">
	      
              <?php if (Auth::user()) : ?> 
               
            <div class="my-3 p-3 bg-white rounded box-shadow col-sm-6 offset-sm-2">
            <div class="card">
                      <div class="card-header">
                        <h3>User Data</h3>
                      </div>
                        <ul class="list-group text-center">
                           <li class="list-group-item">Firstname: &nbsp;<?php echo e(Auth::user()->firstname); ?></li>
                            <li class="list-group-item">lastname:  &nbsp;<?php echo e(Auth::user()->lastname); ?></li>
                             <li class="list-group-item">Email:  &nbsp;<?php echo e(Auth::user()->email); ?></li>
                              <li class="list-group-item">city:  &nbsp;<?php echo e(Auth::user()->city); ?></li>
                        </ul>
                     </div>
            </div>
            <?php endif; ?>

        
    </main>


      <?php $__env->stopSection(); ?>
<?php echo $__env->make('my_layout.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\owner\Pmanager\resources\views/admin/profile.blade.php ENDPATH**/ ?>