 
 
      <?php $__env->startSection('content'); ?>
     
     <br> <br>

        <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">

                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/Dashboard</span>
                                            </li>
                                                                                  </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       
  
                  <?php if(session('status')): ?>
                        <div class="alert alert-success" role="alert">
                            <?php echo e(session('status')); ?>

                        </div>
                    <?php endif; ?>
        <div class="analytics-sparkle-area">
            <div class="container-fluid">
                <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line reso-mg-b-30">
                            <div class="analytics-content">
                                      <h5>Companies</h5>
                                <h1>*<span class="counter  text-danger"><?php echo e($company); ?></span> <span class="tuition-fees">companies</span></h1>

                              
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line reso-mg-b-30">
                            <div class="analytics-content">
                                 <h5> Projects</h5>
                                <h1><i class="fa fa-ruppees"></i><span class="counter  text-success"><?php echo e($project); ?></span> <span class="tuition-fees">projects</span></h1>
                            </div>
                        </div>
                    </div>

                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                       
                                <h5>Tasks</h5>
                                <h2>*<span class="counter  text-info"><?php echo e($task); ?></span> <span class="tuition-fees">tasks</span></h2>
                         
                            </div>
                        </div>
                    </div>
                    
                   <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                       
                                <h5>Roles</h5>
                                <h2>*<span class="counter  text-warning"><?php echo e($role); ?></span> <span class="tuition-fees">roles</span></h2>
                         
                            </div>
                        </div>
                    </div>
                    
              
            </div>
        </div></div>
        <br><br> <br><br>
     
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('my_layout.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\owner\Pmanager\resources\views/admin/home.blade.php ENDPATH**/ ?>