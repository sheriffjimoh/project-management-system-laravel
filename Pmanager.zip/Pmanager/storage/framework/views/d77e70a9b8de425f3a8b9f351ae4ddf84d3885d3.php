 <?php echo $__env->make('layout.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
 
     <div class="error-pagewrap">
		<div class="error-page-int">
           <img class="main-logo" src="" alt="" style="width: 120px;"  / ><br>
			<div class="text-center m-b-md custom-login">
				<h3>WELCOME BACK!</h3>
				<p>Please login to my project management app</p>
			</div>
           
			<div class="content-error">
				<div class="hpanel">
                    <div class="panel-body">
                        <form action="login.php" id="loginForm" method="POST">
                            <div class="form-group">
                                <label class="control-label" for="username">Username</label>
                                <input type="text" placeholder="username" name="username" title="Please enter you username" required="" id="username" class="form-control">
                                <span class="help-block small">Your unique username to app</span>
                            </div>
                            <div class="form-group">
                                <label class="control-label" for="password">Password</label>
                                <input type="password" title="Please enter your password"   name="password" class="form-control" required="">
                                <span class="help-block small">Your strong password</span>
                            </div>
                            <button class="btn btn-success btn-block loginbtn" type="submit"  name="login">Login</button>
                        </form>
                    </div>
                </div>
			</div>
<?php /**PATH C:\Users\owner\Pmanager\resources\views/index.blade.php ENDPATH**/ ?>