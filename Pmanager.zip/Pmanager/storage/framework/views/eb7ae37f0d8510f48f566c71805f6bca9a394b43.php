
 
      <?php $__env->startSection('content'); ?>
       <br><br>
        <!-- Mobile Menu end -->
            <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">
                                         <h3>Facebook Details</h3>
                                        </div>
                                    </div>
                                   
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="/home">Home</a> <span class="bread-slash">/</span>
                                            </li>
                                            <li><span class="bread-blod">Companies</span>
                                            </li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>





        <main role="main" class="container bg-white">
     

      <div class="my-3 p-3  rounded box-shadow">
        <!-- <h6 class="border-bottom border-gray pb-2 mb-0">sorted by date</h6> -->
        <div class="media text-muted pt-3">
         <a href="/companies-details"> <img src="<?php echo e(asset('app-assets/img/logo/facebook.png')); ?>" alt="" class=""  width="120" style="margin-bottom: 30px; height: 80px; margin-right: 20px;"></a>
          <p class="media-body pb-3 mb-0 small lh-125 border-bottom border-gray">
            <strong class="d-block text-gray-dark"><a href="/companies-details"> Facebook</a></strong>
            Donec id elit non mi porta gravida at eget metus. Fusce dapibus, tellus ac cursus commodo, tortor mauris condimentum nibh, ut fermentum massa justo sit amet risus.
            <br>
            <strong class="d-block text-gray-dark"><a href=""> sempt 9, 2020</a></strong>
          </p>
          </div>
           
       

         <!-- List group -->
            <div class="offset-lg-1" id="myList">
            <div  class="btn-group" id="mytabList" role="tablist">
              <a class="btn btn-primary active" data-toggle="list" href="#project" id="project-tab" role="tab">Project</a>
              <a class="btn btn-primary" data-toggle="list" href="#task" id="task-tab" role="tab">Task</a>
              <a class="btn btn-primary" data-toggle="list" href="#post" id="post-tab" role="tab">Post</a>
              <a class="btn btn-primary" data-toggle="list" href="#comments" id="comments-tab" role="tab">Comments</a>
            </div>

            <!-- Tab panes -->
            <div class="tab-content">
              <div class="tab-pane active" id="project" role="tabpanel"> 
               
                <ul class="list-group">
                  <li class="list-group-item d-flex justify-content-between align-items-center">
                    First project of the year
                    <span class="badge badge-success badge-pill">current</span>
                  </li>
                  <li class="list-group-item d-flex justify-content-between align-items-center">
                    First project of the year
                    <span class="badge badge-success badge-pill">current</span>
                  </li>
                 <li class="list-group-item d-flex justify-content-between align-items-center">
                    First project of the year
                    <span class="badge badge-success badge-pill">current</span>
                  </li>
                </ul>            

              </div>
              <div class="tab-pane" id="task" role="tabpanel">task...</div>
              <div class="tab-pane" id="post" role="tabpanel"> post...</div>
              <div class="tab-pane" id="comments" role="tabpanel">comment...</div>
            </div>
            </div>
           <!--  <small class="d-block text-right mt-3">
          <a href="#">View All</a>
        </small> -->
      
         </div>
    </main>
     <?php $__env->stopSection(); ?>
<?php echo $__env->make('layout.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\owner\Pmanager\resources\views//admin/companies-details.blade.php ENDPATH**/ ?>