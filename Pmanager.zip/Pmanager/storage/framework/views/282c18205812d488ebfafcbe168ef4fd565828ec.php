

<!-- Add -->
<div class="modal fade" id="addcompany">
    <div class="modal-dialog">
        <div class="modal-content">
          	<div class="modal-header">
            	<button type="button" class="close" data-dismiss="modal" aria-label="Close">
              		<span aria-hidden="true">&times;</span></button>
            	<h4 class="modal-title"><b>Add nominees of the year</b></h4>
          	</div>
          	<div class="modal-body">
            	<form class="form-horizontal" method="POST" action="../class/process/action.php" enctype="multipart/form-data">
          		    <div class="form-group">
                    <label for="Position" class="col-sm-3 control-label">Fullname</label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="position" name="fname" required>
                    </div>
                </div>
               
                 <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Age </label>

                    <div class="col-sm-9">
                      <input type="text" class="form-control" id="position" name="age" required>
                    </div>
                </div>
                   <div class="form-group">
                    <label for="" class="col-sm-3 control-label">Gender</label>

                    <div class="col-sm-9">
                     <select name="gender" class="form-control">
                       <option selected disabled>select gender---</option>
                       <option value="male">Male</option>
                       <option value="female">Female</option>
                     </select>
                    </div>
                </div>
                 <div class="form-group">
                    <label for="datepicker_add" class="col-sm-3 control-label">Overview</label>
                     <div class="col-sm-9">
                      <textarea class="form-control" name="overview"  required></textarea>
                    </div>
                </div> 
                <div class="form-group">
                    <label for="contact" class="col-sm-3 control-label">Add Image</label>

                    <div class="col-sm-9">
                      <input type="file" class="form-control"  name="photo" required>
                    </div>
                </div>
          	<div class="modal-footer">
            	<button type="button" class="btn btn-default btn-flat pull-left" data-dismiss="modal"><i class="fa fa-close"></i> Close</button>
            	<button type="submit" class="btn btn-primar btn-flat"  style=" background: #006DF0; color: #fff;" name="add_nominee"><i class="fa fa-save"></i> Save</button>
            	</form>
          	</div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\owner\Pmanager\resources\views/admin/includes/addcompany.blade.php ENDPATH**/ ?>