


 <div class="footer-copyright-area">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="footer-copy-right">
                            <p>
  Copyright &copy;<script>document.write(new Date().getFullYear());</script> All rights reserved</a>
  </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
<?php echo $__env->make('my_layout.script', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php /**PATH C:\Users\owner\Pmanager\resources\views/my_layout/footer.blade.php ENDPATH**/ ?>