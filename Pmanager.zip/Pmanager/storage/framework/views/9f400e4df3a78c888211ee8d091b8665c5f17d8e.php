 
 
      <?php $__env->startSection('content'); ?>
     
        <div class="breadcome-area">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-lg-12 col-md-12 col-sm-12 col-xs-12">
                            <div class="breadcome-list">
                                <div class="row">
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <div class="breadcome-heading">

                                        </div>
                                    </div>
                                    <div class="col-lg-6 col-md-6 col-sm-6 col-xs-12">
                                        <ul class="breadcome-menu">
                                            <li><a href="#">Home</a> <span class="bread-slash">/Dashboard</span>
                                            </li>
                                                                                  </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
       

        <div class="analytics-sparkle-area">
            <div class="container-fluid">
                <div class="row">
                  <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line reso-mg-b-30">
                            <div class="analytics-content">
                                      <h5>Voters</h5>
                                <h1>*<span class="counter  text-danger">543</span> <span class="tuition-fees">voter</span></h1>

                                <a href="voters.php" class="btn btn-flat btn-default">see details</a>
                              
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line reso-mg-b-30">
                            <div class="analytics-content">
                                 <h5> Expenses</h5>
                                <h1><i class="fa fa-ruppees"></i><span class="counter  text-success">5454</span> <span class="tuition-fees">expense</span></h1>
                           <a href="fundexpenses.php" class="btn btn-flat btn-default">see details</a>
                            </div>
                        </div>
                    </div>

                         <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                       
                                <h5>Constituency</h5>
                                <h2>*<span class="counter  text-info">55</span> <span class="tuition-fees">constituency</span></h2>
                                <a href="constituency.php" class="btn btn-flat btn-default">see details</a>
                 
                                 
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line reso-mg-b-30 table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                                <h5>Polling booth</h5>
                                <h2>*<span class="counter  text-warning">44</span> <span class="tuition-fees">booth</span></h2>
                                      <a href="booth.php" class="btn btn-flat btn-default">see details</a>
                            </div>
                        </div>
                    </div></div>
                    <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
            
                                    <h5>Release Funds</h5>
                                <h1>*<span class="counter  text-danger">677754</span> <span class="tuition-fees">funds</span></h1>
                                <a href="sms.php" class="btn btn-flat btn-default">see details</a>
                            </div>
                        </div>
                    </div>
                    

                     <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                           <h5>Duplicate Voters</h5>
  
                 
                <h2>*<span class="text-danger">voters</span> <span class="tuition-fees">voter</span></h2>
                      <a href="voters.php" class="btn btn-flat btn-default">see details</a>

                                 
                            </div>
                        </div>
                    </div>
                      <div class="col-lg-3 col-md-6 col-sm-6 col-xs-12">
                        <div class="analytics-sparkle-line table-mg-t-pro dk-res-t-pro-30">
                            <div class="analytics-content">
                               
                                <h5>Managers</h5>
                                <h2>*<span class="counter  text-warning">6</span> <span class="tuition-fees">manager</span></h2>
                                 <a href="manager.php" class="btn btn-flat btn-default">see details</a>
                            </div>
                        </div>
                    </div></div>
           
              
            </div>
        </div></div>
     
      <?php $__env->stopSection(); ?>

<?php echo $__env->make('layout.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\owner\Pmanager\resources\views//admin/home.blade.php ENDPATH**/ ?>