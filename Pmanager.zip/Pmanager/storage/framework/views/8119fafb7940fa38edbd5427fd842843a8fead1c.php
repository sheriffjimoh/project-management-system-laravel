 <!-- 
 
      <?php $__env->startSection('content'); ?>
     
      <h1>welcome page</h1>

      <?php $__env->stopSection(); ?> -->

<?php echo $__env->make('layout.appbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\owner\Pmanager\resources\views/welcome.blade.php ENDPATH**/ ?>